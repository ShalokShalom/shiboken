/****************************************************************************
**
** Copyright (C) 2016 The Qt Company Ltd.
** Contact: https://www.qt.io/licensing/
**
** This file is part of the test suite of PySide2.
**
** $QT_BEGIN_LICENSE:GPL-EXCEPT$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** GNU General Public License Usage
** Alternatively, this file may be used under the terms of the GNU
** General Public License version 3 as published by the Free Software
** Foundation with exceptions as appearing in the file LICENSE.GPL3-EXCEPT
** included in the packaging of this file. Please review the following
** information to ensure the GNU General Public License requirements will
** be met: https://www.gnu.org/licenses/gpl-3.0.html.
**
** $QT_END_LICENSE$
**
****************************************************************************/

#ifndef OBJ_H
#define OBJ_H

#include "libminimalmacros.h"

class LIBMINIMAL_API Obj
{
public:
    explicit Obj(int objId);
    virtual ~Obj();

    int objId() { return m_objId; }
    void setObjId(int objId) { m_objId = objId; }

    virtual bool virtualMethod(int val);
    bool callVirtualMethod(int val) { return virtualMethod(val); }

    virtual Obj* passObjectType(Obj* obj) { return obj; }
    Obj* callPassObjectType(Obj* obj) { return passObjectType(obj); }

    virtual Obj* passObjectTypeReference(Obj& obj) { return &obj; }
    Obj* callPassObjectTypeReference(Obj& obj) { return passObjectTypeReference(obj); }

private:
    Obj(const Obj&);
    Obj& operator=(const Obj&);
    int m_objId;
};

#endif // OBJ_H

